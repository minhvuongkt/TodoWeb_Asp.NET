﻿

/*function deleteUser() {
    Swal.fire({
        title: 'Bạn có chắc chắn?',
        text: "Hành động này không thể hoàn tác!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText:
            'Đồng ý',
        cancelButtonText: 'Hủy'
    }).then((result) => {
        if (result.isConfirmed) {
            let UniqueID = $('#uniqueID').text();
            $.ajax({
                type: "POST",
                url: "./Delete",
                data: { UniqueID: UniqueID },
                success: function (response) {
                    alert(response.message);
                    if (response.success) {
                        window.location.href = "./";
                    }
                }
            });
        }
    });
}*/
