﻿let title = document.getElementById('title');

$(document).ready(function () {
    const hash = window.location.hash.substring(1);
    if (hash === "Register") {
        showRegisterForm();
    }
    else {
        showLoginForm();
    }
});

function showRegisterForm() {
    title.innerHTML = "Đăng Ký";
    $('#registerForm').removeClass('hidden');
    $('#loginForm').addClass('hidden');
}

function showLoginForm() {
    title.innerHTML = "Đăng Nhập";
    $('#loginForm').removeClass('hidden');
    $('#registerForm').addClass('hidden');
}

function login() {
    let userName = $('#usernameLogin').val()
    let passWord = $('#passwordLogin').val()
    if (userName == "" || passWord == "" || userName == null || passWord == null) {
        alertt("Vui lòng nhập thông tin", true);
        return;
    }
    $.ajax({
        type: "POST",
        url: "./Login",
        data: { userName: userName, password: passWord },
        success: function (response) {
            alert(response.message);
            if (response.success) {
                window.location.href = "../";
            }
        }
    });
}
function getRandomInt(min, max) {
    if (min > max) {
        [min, max] = [max, min];
    }
    return Math.floor(Math.random() * (max - min + 1)) + min;
}
function isGmail(email) {
    const gmailRegex = /^[^\s@]+@gmail\.com$/;
    return gmailRegex.test(email);
}
function checkPasswordStrength(password) {
    const strongRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
    const mediumRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[A-Za-z\d]{8,}$/;

    if (strongRegex.test(password)) {
        return 2;
    } else if (mediumRegex.test(password)) {
        return 1;
    } else {
        return 0;
    }
}
function register() {
    var formReg = {
        UserName: $('#usernameReg').val(),
        Password: $('#passwordReg').val(),
        FullName: $('#name').val(),
        Email: $('#email').val()
    };
    console.log(isGmail($('#email').val()));
    if ($('#usernameReg').val() == "" || $('#passwordReg') == "" || $('#name').val() == "" || $('#email').val() == "") {
        alert("Vui lòng nhập thông tin");
        return;
    }
    else if (isGmail($('#email').val()) == false) {
        alert("Vui lòng nhập đúng định dạng Gmail");
        return;
    }
    else if ($('#usernameReg').val().length < 6) {
        alert("Username không được ngắn hơn 6 kí tự.");
        return;
    }
    else if ($('#passwordReg').val().length < 6 || checkPasswordStrength($('#passwordReg').val()) < 2) {
        alert("Mật khẩu dễ đoán, vui lòng đặt mật khẩu mạnh hơn!");
        return;
    }
    else {
        $.ajax({
            type: "POST",
            url: "./Register",
            data: formReg,
            success: function (response) {
                alert(response.message);
                if (response.success) {
                    window.location.href = "../";
                }
            }
        });
    }
}