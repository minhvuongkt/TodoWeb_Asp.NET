﻿function changepass() {
    let oldPass = $('#oldPass').val()
    let passWord = $('#newPass').val()
    if (oldPass == "" || passWord == "" || oldPass == null || passWord == null) {
        alert("Vui lòng nhập thông tin");
        return;
    }
    $.ajax({
        type: "POST",
        url: "./ChangeUserPwd",
        data: { oldPass: oldPass, newPass: passWord },
        success: function (response) {
            alert(response.message);
            if (response.success) {
                window.location.href = "./Logout";
            }
        }
    });
}