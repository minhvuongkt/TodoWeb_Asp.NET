﻿$(document).ready(function () {
    $(".btn-edit").click(function (e) {
        e.preventDefault();
        var link = $(this).data("url");
        $.ajax({
            url: link,
            type: "GET",
            error: function (xhr, status, error) {
                alert("Đã xảy ra lỗi: " + error);
                console.error(xhr.responseText);
            },
            success: function (data) {
                $("#dialogModal").modal('hide');
                $("#dialogModal").empty();
                $("#dialogModal").html(data);
                $("#dialogModal").modal({ backdrop: 'static', keyboard: false });
            }
        });
    });
    $(".btn-delete").click(function (e) {
        e.preventDefault();
        var link = $(this).data("url");
        $.ajax({
            url: link,
            type: "GET",
            error: function (xhr, status, error) {
                alert("Đã xảy ra lỗi: " + error);
                console.error(xhr.responseText);
            },
            success: function (data) {
                $("#dialogModal").modal('hide');
                $("#dialogModal").empty();
                $("#dialogModal").html(data);
                $("#dialogModal").modal({ backdrop: 'static', keyboard: false });
            }
        });
    });
})