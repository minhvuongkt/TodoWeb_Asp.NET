﻿function submitt() {

    var formTask = {
        Title: $("#nametask").val(),
        Description: $('#destask').val(),
        IsFinished: false,
        UserId: `@HttpContextAccessor.HttpContext.Session.GetInt32("UserId")`,
        TimeCreated: $('#timestart').val(),
        TimeUpdated: $('#timeend').val()
    };
    //console.log(formTask)
    $.ajax({
        type: "POST",
        url: "./Create",
        data: formTask,
        success: function (response) {
            alert(response.message);
            if (response.success) {
                window.location.href = "../";
            }
        }
    });
}